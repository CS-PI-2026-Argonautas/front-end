enum StatusOrdemServico {
  EM_ORCAMENTO,
  EM_CONSERTO,
  CANCELADA,
  CONCLUIDA,
  ENTREGUE,
  PAGA,
}
