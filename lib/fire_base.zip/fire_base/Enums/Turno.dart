enum Turno { NOTURNO, DIURNO }
