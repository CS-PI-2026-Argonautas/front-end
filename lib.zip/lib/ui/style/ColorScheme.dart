import 'dart:ui';

import 'package:flutter/material.dart';

final colorScheme = ColorScheme(
  brightness: Brightness.light, //tema claro
  primary: const Color(0xFF2596be), //cor primária #f0f5f7
  onPrimary: Colors.white, //elementos em cima da cor primária
  secondary: const Color(0xFF2582BE), //cor secundária
  onSecondary: Colors.white, //elementos em cima da cor secundária
  tertiary: const Color(0xFF256CBE),
  onTertiary: Colors.white,
  error: const Color(0xFFd93c26), //mensagens de erro
  onError: Colors.white, //elementos em cima do erro
  surface: const Color(0xFFd8e1e4), //cor de fundo
  surfaceContainer: const Color(0xFFf6f8f9), //cor de fundo de componentes
  surfaceContainerHigh: const Color(
    0xFFcfe0e5,
  ), //cor de fundo de componentes em destaque
  onSurface: Colors.blueGrey.shade800, //textos
  onSurfaceVariant: Colors.blueGrey.shade500,
  //textos secundários
  surfaceContainerLow: const Color(0xFFdeecee), //cor de fundo de componentes em baixo destaque
  surfaceContainerHighest: const Color.fromARGB(255, 217, 229, 238) //cor de fundo de componentes em maior destaque
);
