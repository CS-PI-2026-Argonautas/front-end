import 'package:frontend/ui/pages/dashboard.dart';
import 'package:frontend/ui/style/ColorScheme.dart' as custom_colors;
import 'package:flutter/material.dart';

class ItemEdition extends StatelessWidget {
  const ItemEdition({super.key});

  @override
  Widget build(BuildContext context) {
    final colors = custom_colors.colorScheme;

    return Scaffold(
      backgroundColor: colors.surface,
      body: Center(
        child: Column(
          spacing: 24,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Em construção",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: colors.onSurface,
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => const Dashboard()),
                  (route) => false,
                );
              },
              child: const Text("Voltar"),
              style: ElevatedButton.styleFrom(
                elevation: 3,
                backgroundColor: colors.primary,
                foregroundColor: colors.onSecondary,
                padding: const EdgeInsets.symmetric(vertical: 18),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
