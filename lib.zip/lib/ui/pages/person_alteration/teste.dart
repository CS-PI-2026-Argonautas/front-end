import 'package:flutter/material.dart';
import 'package:frontend/ui/pages/person_alteration/person_alteration.dart';


void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: PersonAlteration(),
    );
  }
}